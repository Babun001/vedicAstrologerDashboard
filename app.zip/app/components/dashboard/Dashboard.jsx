"use client";

import { useState } from "react";
import LoginView from "../login/LoginView";
import { Sidebar } from "../layout/Sidebar";
import { TopBar } from "../layout/TopBar";
import { LotusWatermark } from "../common/LotusWatermark";
import { MyWorkView } from "../work/MyWorkView";
import CreateReport from "../work/CreateReport";
import { InboxView } from "../inbox/InboxView";
import { TasksView } from "../tasks/TasksView";
import axiosInstanceClient from "../services/client.services";
import { useEffect } from "react";

export default function Dashboard() {
  const [authed, setAuthed] = useState(false);
  const [view, setView] = useState("work");
  const [activeConvo, setActiveConvo] = useState("c2");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [selectedReportId, setSelectedReportId] = useState(null);
  const [selectedReport, setSelectedReport] = useState(null);
  const [astrologer, setAstrologer] = useState(null);

  useEffect(() => {
    if (!authed) return;
    axiosInstanceClient
      .get("/astrologer/profile")
      .then((res) => setAstrologer(res.data.data.astrologer))
      .catch((err) => console.error("Failed to load profile:", err));
  }, [authed]);

  const handleLogout = async () => {
    try {
      await axiosInstanceClient.post("/astrologer/logout");

      console.log("Astrologer logged out successfully");
    } catch (error) {
      console.error("Astrologer logout failed:", error);
    } finally {
      // Logout from frontend even if API fails
      localStorage.removeItem("astrologerToken");
      setAuthed(false);
    }
  };

  return (
    <div className="cr-root">
      <div className="cr-grain" aria-hidden="true" />

      {!authed ? (
        <LoginView onLogin={() => setAuthed(true)} />
      ) : (
        <div className="cr-shell">
          {mobileNavOpen && (
            <div
              className="cr-mobile-backdrop"
              onClick={() => setMobileNavOpen(false)}
            />
          )}

          <Sidebar
            view={view}
            setView={setView}
            mobileNavOpen={mobileNavOpen}
            onCloseMobile={() => setMobileNavOpen(false)}
            onSignOut={handleLogout}
          />

          <main className="cr-main">
            <LotusWatermark
              className="cr-content-mandala"
              size={520}
              opacity={0.08}
            />

            <LotusWatermark
              className="cr-content-mandala-2"
              size={280}
              opacity={0.07}
            />

            <TopBar view={view} astrologer={astrologer} onMenuClick={() => setMobileNavOpen(true)} />

            <div className="cr-content">
              {view === "work" && <MyWorkView />}

              {view === "inbox" && (
                <InboxView
                  activeConvo={activeConvo}
                  setActiveConvo={setActiveConvo}
                />
              )}

              {view === "tasks" && (
                <TasksView
                  onGenerateReport={(report) => {
                    setSelectedReportId(report);
                    setView("create-report");
                  }}
                />
              )}

              {view === "create-report" && (
                <CreateReport report={selectedReportId} />
              )}
            </div>
          </main>
        </div>
      )}
    </div>
  );
}
